English: [https://yaoapps.com/en-US/doc](https://yaoapps.com/en-US/doc)

中文: [https://yaoapps.com/doc](https://yaoapps.com/doc)
