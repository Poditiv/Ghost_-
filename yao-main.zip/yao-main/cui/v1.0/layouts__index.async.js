var path = "/__yao_admin_root/";
var foo = concat("__yao_admin_root");
