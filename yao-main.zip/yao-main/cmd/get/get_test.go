package get

import (
	"testing"
)

func TestUnpack(t *testing.T) {
	// pkg, err := New("yaoapp/demo-app")
	// if err != nil {
	// 	t.Fatal(err)
	// }

	// if err := pkg.Download(); err != nil {
	// 	t.Fatal(err)
	// }

	// dest, err := os.MkdirTemp("", "*-unit-test")
	// if err != nil {
	// 	t.Fatal(err)
	// }

	// defer os.RemoveAll(dest)
	// app, err := pkg.Unpack(dest)
	// if err != nil {
	// 	t.Fatal(err)
	// }

	// assert.NotNil(t, app.Name)
}
